
// Clase principal para probar el proyecto
public class Main {
    public static void main(String[] args) {
        GestorDeArchivo gestor = new GestorDeArchivo();
        ValidadorArchivo validador = new ValidadorArchivo();

        String nombreArchivo = "ejemplo.txt";
        String contenido = "Hola Nathaly, este es un ejemplo de manipulación de archivos en Java.";

        // Guardar contenido en el archivo
        gestor.guardar(nombreArchivo, contenido);

        // Leer el contenido
        String textoLeido = gestor.leer(nombreArchivo);
        System.out.println("Contenido del archivo:");
        System.out.println(textoLeido);

        // Verificar si el archivo está vacío
        try {
            validador.verificarNoVacio(nombreArchivo);
            System.out.println("El archivo no está vacío.");
        } catch (ArchivoVacioException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
